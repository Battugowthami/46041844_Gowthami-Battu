const person ={
    name:"Gowthami",
    talk(){
        console.log(this);
    }
}
person.talk();

const talk = person.talk.bind(person);
talk();
